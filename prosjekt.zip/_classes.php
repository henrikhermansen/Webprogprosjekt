<?php if(!$gjennomIndex) die("Access denied.");?>

<?php

require_once"classes/admin.php";
require_once"classes/handlekurv.php";
require_once"classes/kunde_basic.php";
require_once"classes/kunde.php";
require_once"classes/kunde_ny.php";
require_once"classes/ordre.php";
require_once"classes/sql.php";
require_once"classes/vare.php";
require_once"classes/kategori.php";

?>
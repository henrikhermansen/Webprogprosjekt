<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="nettbutikk.css" title="Standard css" />
<title>HBHL nettbutikk</title>
</head>
<body>

<div id="hovedramme">

<div id="header">
    <h1><a href="index.php?side=hjem">HBHL nettbutikk</a></h1>
</div>

<div id="l_meny"></div>

<div id="innhold">
	<h2>Det oppsto en uopprettelig feil</h2>
	<p>Det oppsto en uopprettelig feil, og vi vil fors�ke � rette denne s� fort som mulig.</p>
	<p>I mellomtiden kan du <a href="index.php?side=hjem">g� tilbake</a> og gj�re noe annet.</p>
</div>

<div id="r_meny"></div>

</div>
</body>
</html>

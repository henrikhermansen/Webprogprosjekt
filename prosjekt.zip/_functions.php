<?php if(!$gjennomIndex) die("Access denied.");?>

<?php

require_once"functions/error_handling.php";
require_once"functions/cryptPass.php";
require_once"functions/fixSpecialChars.php";
require_once"functions/genPassord.php";
require_once"functions/now.php";
require_once"functions/renStreng.php";
require_once"functions/sjekkPostnr.php";
require_once"functions/getVarer.php";
require_once"functions/getKategorier.php";

?>
function bekreftSletting(url)
{
	if(confirm("Er du sikker p� at du vil utf�re denne slettingen?"))
		window.location=url;
}
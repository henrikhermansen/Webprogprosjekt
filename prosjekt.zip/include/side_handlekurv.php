<?php if(!$gjennomIndex) die("Access denied.");?>

<h3>Handlekurv</h3>

<?php echo $handlekurv->visHandlekurv(); ?>

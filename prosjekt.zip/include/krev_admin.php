<?php if(!$gjennomIndex) die("Access denied.");?>

<p class="feilmelding">Denne siden krever innlogging som administrator. Vennligst logg deg inn.</p>

<?php include"admlogginn.php"; ?>
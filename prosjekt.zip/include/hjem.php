<?php if(!$gjennomIndex) die("Access denied.");?>

<h2>Velkommen til HBHL nettbutikk!</h2>

<p>Vi f�rer alt av digitalt fotoutstyr fra alle de store kvalitetsprodusentene.
Vi har det du trenger - uansett om du er profesjonell fotograf eller bare trenger
et godt kamera til ferieturen!</p>
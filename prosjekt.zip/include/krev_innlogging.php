<?php if(!$gjennomIndex) die("Access denied.");?>

<p class="feilmelding">Denne siden krever innlogging. Vennligst logg inn eller <a href="index.php?side=nykunde">registrer deg som ny kunde</a>.</p>

<?php include"logginn.php"; ?>
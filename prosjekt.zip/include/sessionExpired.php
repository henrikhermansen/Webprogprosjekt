<?php if(!$gjennomIndex) die("Access denied.");?>

<h1>Ny innlogging</h1>

<p class="feilmelding">Du har v�rt innlogget i 30 minutter uten � foreta deg noe. Vennligst <a href="index.php?side=logginn">logg inn</a> p� nytt</p>
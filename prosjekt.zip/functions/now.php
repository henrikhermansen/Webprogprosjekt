<?php if(!$gjennomIndex) die("Access denied.");?>

<?php

function now()
{
	return date("Y-m-d H:i:s");
}

?>